import { test, expect } from '@playwright/test';

test('Automate flight status API and assert the response', async ({ request }) => {
  // Define the POST request payload
  const payload = {
    airlineCode: "EW",
    departureDate: "2024-10-05",
    flightNumber: "6"
  };

  // Make the POST API request
  const response = await request.post('https://www.eurowings.com/flightstatus.search.flightNumber.nocache.html', {
    headers: {
      'Content-Type': 'application/json'
    },
    data: payload
  });

  // Log the response text to check if it's HTML or JSON
  const responseText = await response.text();
  console.log('Response Text:', responseText);

  // If the response contains JSON, parse it
  try {
    const responseBody = await response.json();

    // Assert that the response contains correct flight status information
    expect(responseBody.resultData.flights[0].departureTLC).toBe('CGN');
    expect(responseBody.resultData.flights[0].destinationTLC).toBe('BER');
    expect(responseBody.resultData.flights[0].flightStatus.label).toBe('on time');
  
    // Log some of the flight details
    console.log('Flight Number:', responseBody.resultData.flights[0].flightNumber);
    console.log('Departure Time:', responseBody.resultData.flights[0].departureTime);
    console.log('Arrival Time:', responseBody.resultData.flights[0].arrivalTime);
  } catch (error) {
    console.error('Failed to parse JSON response:', error);
  }
});
