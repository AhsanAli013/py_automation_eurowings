import { chromium, Browser, Page } from 'playwright';

// Test Case 1: Validate flight status by flight route
async function testFlightStatusByRoute() {
  const browser: Browser = await chromium.launch({ headless: false });
  const page: Page = await browser.newPage();
  await page.goto('https://www.eurowings.com/en/information/at-the-airport/flight-status.html');
  //giving website privacy setting concent
  await page.click('.cookie-consent--cta-accept');
  // Selecting the Flight Route radio button by name and value
  //await page.click('input[name="search-method"][value="FLIGHT_ROUTE"]');
  //secting flight deperting airport
  await page.click('div.o-station-select:nth-child(1) > div:nth-child(1) > div:nth-child(1) > button:nth-child(1) > div:nth-child(2) > span:nth-child(1)');
  await page.fill('.a-input-text__input--deco-icon.a-input-text__input.m-form-autocomplete__input-field', 'CGN');
  await page.waitForTimeout(1000);
  await page.click('.o-station-select__new-station-list__text');
  await page.waitForTimeout(1000);
  //selecting flight destination
  await page.click('div.o-station-select:nth-child(2) > div:nth-child(1) > div:nth-child(1) > button:nth-child(1) > div:nth-child(2)');
  await page.waitForTimeout(1000);
  await page.fill('.a-input-text__input--deco-icon.a-input-text__input.m-form-autocomplete__input-field', 'BER');
  await page.waitForTimeout(1000);
  await page.click('.o-station-select__new-station-list__label-text')
  await page.waitForTimeout(1000);
  //adding flight date
  await page.click('label.styles-module__Label--hP3Bt:nth-child(3)');
  await page.waitForTimeout(1000);
  await page.click('.calendar-table > tbody:nth-child(2) > tr:nth-child(1) > td:nth-child(7) > div:nth-child(1) > input:nth-child(1)');
  await page.waitForTimeout(1000);
  //clicking show flights btn
  await page.click('button.a-cta-prio1:nth-child(1)');
  await page.waitForTimeout(1000);
  //validating search results
  const result = await page.$('div.o-search-flight-status__card:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2)');
  await page.waitForTimeout(1000);
  if (result) {
    console.log('Flights exists for given route');
  } else {
    console.log('No flight status available for the given route and date.');
  }
  await page.waitForTimeout(3000);

  await browser.close();
}

// Test Case 2: Validate flight status by flight number
async function testFlightStatusByNumber() {
  const browser: Browser = await chromium.launch({ headless: false });
  const page: Page = await browser.newPage();
  await page.goto('https://www.eurowings.com/en/information/at-the-airport/flight-status.html');
  //giving website privacy setting concent
  await page.click('.cookie-consent--cta-accept');
  // Selecting the Flight Number radio button by name and value
  await page.click('input[name="search-method"][value="FLIGHT_NUMBER"]');
  await page.waitForTimeout(1000);
  //adding flight number
  await page.click('.styles-module__Label--I24B9');
  await page.waitForTimeout(1000);
  await page.fill('.styles-module__Label--I24B9', 'EW-1234'); //change flight no here
  await page.waitForTimeout(1000);
  //adding flight date
  await page.click('.styles-module__HasIcon--Ar6AQ');
  await page.click('.calendar-table > tbody:nth-child(2) > tr:nth-child(1) > td:nth-child(7) > div:nth-child(1) > input:nth-child(1)');
  await page.waitForTimeout(1000);
  //clicking show flights btn
  await page.click('button.a-cta-prio1:nth-child(1)');
  await page.waitForTimeout(1000);
  //validating search results
  
  const result = await page.$('div.o-search-flight-status__card:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2)');
  await page.waitForTimeout(1000);
  if (result) {
    console.log('Flights exists for given flight number');
  } else {
    console.log('No flight status available for the given flight number and date.');
  }
  await page.waitForTimeout(3000);


  await browser.close();
}
// Test Case 3: Validate flight by Flight Number on different dates
async function navigateBetweenDates() {
  const browser: Browser = await chromium.launch({ headless: false });
  const page: Page = await browser.newPage();
  await page.goto('https://www.eurowings.com/en/information/at-the-airport/flight-status.html');
  //giving website privacy setting concent
  await page.click('.cookie-consent--cta-accept');
  // Selecting the Flight Number radio button by name and value
  await page.click('input[name="search-method"][value="FLIGHT_NUMBER"]');
  await page.waitForTimeout(1000);
  //adding flight number
  await page.click('.styles-module__Label--I24B9');
  await page.waitForTimeout(1000);
  await page.fill('.styles-module__Label--I24B9', 'EW-6'); //change flight no here
  await page.waitForTimeout(1000);
  //adding flight date
  await page.click('.styles-module__HasIcon--Ar6AQ');
  await page.click('.calendar-table > tbody:nth-child(2) > tr:nth-child(1) > td:nth-child(7) > div:nth-child(1) > input:nth-child(1)');
  await page.waitForTimeout(1000);
  //clicking show flights btn
  await page.click('button.a-cta-prio1:nth-child(1)');
  await page.waitForTimeout(1000);
  //validating search results for 6/10
  const result = await page.$('div.o-search-flight-status__card:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2)');
  await page.waitForTimeout(1000);
  if (result) {
    console.log('Flights exists for given flight number on 06/10');
  } else {
    console.log('No flight status available for the given flight number on 06/10.');
  }
  await page.waitForTimeout(1000);
  //change date on 05/10
  await page.click('li.o-search-flight-status__date-navigation__item:nth-child(4) > button:nth-child(1)');
  await page.waitForTimeout(2000);
  //checking flights on 05/10
  if (result) {
    console.log('Flights exists for given flight number on 05/10');
  } else {
    console.log('No flight status available for the given flight number on 05/10.');
  }

  await page.waitForTimeout(3000);


  await browser.close();
}

async function runTests() {
  await testFlightStatusByRoute();
  await testFlightStatusByNumber();
  await navigateBetweenDates();
}

runTests();
